import { ChatHeader } from "@/components/chat-header"
import { MessageList } from "@/components/message-list"
import { MessageInput } from "@/components/message-input"

export default function ChatPage() {
  return (
    <>
      <ChatHeader />
      <MessageList />
      <MessageInput />
    </>
  )
}
