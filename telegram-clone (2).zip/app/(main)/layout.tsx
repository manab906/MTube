import type React from "react"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"

export default function MainLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      <Header />
      <div className="flex min-h-screen pt-14">
        <Sidebar />
        <main className="flex-1 ml-0 md:ml-64">{children}</main>
      </div>
    </>
  )
}
