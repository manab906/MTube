import { ShortsCard } from "@/components/shorts-card"

export default function ShortsPage() {
  const shorts = [
    {
      id: 1,
      title: "Amazing trick shot you won't believe!",
      channel: "Sports Highlights",
      channelId: "sports-highlights",
      views: "4.5M",
      likes: "342K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Amazing+Trick+Shot",
    },
    {
      id: 2,
      title: "This dog can speak 5 languages",
      channel: "Animal World",
      channelId: "animal-world",
      views: "12M",
      likes: "1.2M",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Talented+Dog",
    },
    {
      id: 3,
      title: "How to make perfect pancakes in 60 seconds",
      channel: "Quick Recipes",
      channelId: "quick-recipes",
      views: "2.3M",
      likes: "189K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Perfect+Pancakes",
    },
    {
      id: 4,
      title: "Life hack: Open a bottle without an opener",
      channel: "Life Hacks",
      channelId: "life-hacks",
      views: "8.7M",
      likes: "756K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Bottle+Hack",
    },
    {
      id: 5,
      title: "This magic trick will blow your mind",
      channel: "Magic Masters",
      channelId: "magic-masters",
      views: "5.1M",
      likes: "423K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Magic+Trick",
    },
    {
      id: 6,
      title: "Dance tutorial: Learn this viral move",
      channel: "Dance Pro",
      channelId: "dance-pro",
      views: "9.3M",
      likes: "812K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Dance+Tutorial",
    },
    {
      id: 7,
      title: "Fastest way to peel a potato",
      channel: "Kitchen Tips",
      channelId: "kitchen-tips",
      views: "3.8M",
      likes: "267K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Potato+Peeling",
    },
    {
      id: 8,
      title: "Watch this cat play the piano",
      channel: "Funny Pets",
      channelId: "funny-pets",
      views: "15M",
      likes: "1.5M",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Piano+Cat",
    },
    {
      id: 9,
      title: "3D animation in just 30 seconds",
      channel: "Animation Hub",
      channelId: "animation-hub",
      views: "2.7M",
      likes: "198K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=3D+Animation",
    },
    {
      id: 10,
      title: "The most satisfying video you'll see today",
      channel: "Oddly Satisfying",
      channelId: "oddly-satisfying",
      views: "7.2M",
      likes: "645K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Satisfying+Video",
    },
    {
      id: 11,
      title: "How to draw a perfect portrait in 60 seconds",
      channel: "Art Master",
      channelId: "art-master",
      views: "1.9M",
      likes: "156K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Portrait+Drawing",
    },
    {
      id: 12,
      title: "Incredible parkour skills in the city",
      channel: "Urban Athletes",
      channelId: "urban-athletes",
      views: "6.4M",
      likes: "532K",
      thumbnail: "/placeholder.svg?height=400&width=225&text=Parkour+Skills",
    },
  ]

  return (
    <div className="p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Shorts</h1>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {shorts.map((short) => (
            <ShortsCard key={short.id} short={short} />
          ))}
        </div>
      </div>
    </div>
  )
}
