import Link from "next/link"
import { CategoryPills } from "@/components/category-pills"
import VideoGrid from "@/components/video-grid"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Category Pills */}
        <div className="mb-6 overflow-x-auto pb-2">
          <CategoryPills />
        </div>

        {/* Welcome Message */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8 mb-8 text-center">
          <h1 className="text-2xl font-bold mb-3">Welcome to MTube</h1>
          <p className="text-gray-600 mb-6">Discover videos you'll love from creators around the world</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button className="bg-red-600 hover:bg-red-700 text-white">Explore Now</Button>
            <Link href="/login">
              <Button variant="outline">Sign in to personalize</Button>
            </Link>
          </div>
        </div>

        {/* Recommended Videos */}
        <h2 className="text-xl font-bold mb-4">Recommended for you</h2>
        <VideoGrid />
      </div>
    </div>
  )
}
