import { Suspense } from "react"
import WatchClient from "./client"

// Loading component for Suspense fallback
function WatchLoading() {
  return (
    <div className="p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-2/3">
            {/* Video Player Skeleton */}
            <div className="relative rounded-xl overflow-hidden mb-4 aspect-video bg-gray-200 animate-pulse"></div>

            {/* Title Skeleton */}
            <div className="h-7 bg-gray-200 rounded w-3/4 mb-4 animate-pulse"></div>

            {/* Info Skeleton */}
            <div className="flex justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-gray-200 animate-pulse"></div>
                <div>
                  <div className="h-4 bg-gray-200 rounded w-24 mb-1 animate-pulse"></div>
                  <div className="h-3 bg-gray-200 rounded w-16 animate-pulse"></div>
                </div>
              </div>
            </div>

            {/* Description Skeleton */}
            <div className="bg-gray-100 rounded-xl p-4 mb-6">
              <div className="h-4 bg-gray-200 rounded w-1/3 mb-2 animate-pulse"></div>
              <div className="h-3 bg-gray-200 rounded w-full mb-1 animate-pulse"></div>
              <div className="h-3 bg-gray-200 rounded w-full mb-1 animate-pulse"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3 animate-pulse"></div>
            </div>
          </div>

          {/* Recommended Videos Skeleton */}
          <div className="lg:w-1/3">
            <div className="h-6 bg-gray-200 rounded w-1/2 mb-4 animate-pulse"></div>
            <div className="space-y-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex gap-2">
                  <div className="flex-shrink-0 w-40 aspect-video bg-gray-200 rounded-lg animate-pulse"></div>
                  <div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-1 animate-pulse"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-1 animate-pulse"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/3 animate-pulse"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function WatchPage() {
  return (
    <Suspense fallback={<WatchLoading />}>
      <WatchClient />
    </Suspense>
  )
}
