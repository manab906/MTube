"use client"

import { useSearchParams } from "next/navigation"
import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ThumbsUp, ThumbsDown, Share2, Download, MoreHorizontal, CheckCircle2, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function WatchClient() {
  const searchParams = useSearchParams()
  const videoId = searchParams.get("v") || "1"
  const [isSubscribed, setIsSubscribed] = useState(false)

  // Mock video data
  const video = {
    id: Number.parseInt(videoId),
    title: "How to Build a Modern Website in 2023",
    description:
      "In this comprehensive tutorial, we'll walk through the process of building a modern, responsive website using the latest web technologies. We'll cover HTML, CSS, JavaScript, and how to use popular frameworks to speed up development.",
    views: "1.2M views",
    likes: "45K",
    timestamp: "May 15, 2023",
    channel: "Tech Insights",
    channelId: "tech-insights",
    subscribers: "2.4M subscribers",
    verified: true,
    commentCount: 1024,
  }

  const comments = [
    {
      id: 1,
      user: "WebDev Pro",
      comment:
        "This tutorial was incredibly helpful! I've been struggling with responsive design and this cleared up so many questions I had.",
      likes: 342,
      time: "2 weeks ago",
    },
    {
      id: 2,
      user: "Code Learner",
      comment:
        "Great explanation of the concepts. Would love to see a follow-up video on how to add animations to the website.",
      likes: 128,
      time: "1 week ago",
    },
    {
      id: 3,
      user: "Design Enthusiast",
      comment: "The section on CSS Grid was a game-changer for me. Finally understand how to use it properly!",
      likes: 89,
      time: "3 days ago",
    },
  ]

  return (
    <div className="p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-2/3">
            {/* Video Player */}
            <div className="relative rounded-xl overflow-hidden mb-4 aspect-video bg-black">
              <div className="absolute inset-0 flex items-center justify-center">
                <Image
                  src={`/placeholder.svg?height=480&width=854&text=Video+${videoId}`}
                  alt={video.title}
                  fill
                  className="object-contain"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button className="bg-black/50 hover:bg-black/70 text-white rounded-full w-16 h-16 flex items-center justify-center">
                    <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 5V19L19 12L8 5Z" fill="currentColor" />
                    </svg>
                  </Button>
                </div>
              </div>
            </div>

            {/* Video Info */}
            <h1 className="text-xl font-bold mb-2">{video.title}</h1>

            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2">
                <Link href={`/channel/${video.channelId}`} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-medium">
                    {video.channel.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-medium">{video.channel}</span>
                      {video.verified && <CheckCircle2 className="h-4 w-4 text-gray-500 fill-gray-500" />}
                    </div>
                    <div className="text-xs text-gray-500">{video.subscribers}</div>
                  </div>
                </Link>

                <Button
                  className={
                    isSubscribed ? "bg-gray-200 text-black hover:bg-gray-300" : "bg-red-600 hover:bg-red-700 text-white"
                  }
                  onClick={() => setIsSubscribed(!isSubscribed)}
                >
                  {isSubscribed ? "Subscribed" : "Subscribe"}
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex rounded-full overflow-hidden border border-gray-200">
                  <Button variant="ghost" className="rounded-none border-r border-gray-200 flex gap-1">
                    <ThumbsUp className="h-5 w-5" />
                    <span>{video.likes}</span>
                  </Button>
                  <Button variant="ghost" className="rounded-none">
                    <ThumbsDown className="h-5 w-5" />
                  </Button>
                </div>

                <Button variant="ghost" className="rounded-full">
                  <Share2 className="h-5 w-5 mr-2" />
                  Share
                </Button>

                <Button variant="ghost" className="rounded-full">
                  <Download className="h-5 w-5 mr-2" />
                  Download
                </Button>

                <Button variant="ghost" size="icon" className="rounded-full">
                  <MoreHorizontal className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Video Description */}
            <div className="bg-gray-100 rounded-xl p-4 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium">{video.views}</span>
                <span className="text-gray-500">•</span>
                <span className="text-gray-500">{video.timestamp}</span>
              </div>
              <p className="text-sm">{video.description}</p>
            </div>

            {/* Comments */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-4">
                <MessageSquare className="h-5 w-5" />
                <h3 className="font-medium">{video.commentCount} Comments</h3>
              </div>

              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-white font-medium">
                        {comment.user.charAt(0)}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{comment.user}</span>
                        <span className="text-xs text-gray-500">{comment.time}</span>
                      </div>
                      <p className="text-sm mt-1">{comment.comment}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Button variant="ghost" size="sm" className="h-8 px-2">
                          <ThumbsUp className="h-4 w-4 mr-1" />
                          {comment.likes}
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 px-2">
                          <ThumbsDown className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 px-2">
                          Reply
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recommended Videos */}
          <div className="lg:w-1/3">
            <h2 className="text-lg font-bold mb-4">Recommended videos</h2>
            <div className="space-y-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <Link href={`/watch?v=${i + 10}`} key={i} className="flex gap-2 group">
                  <div className="flex-shrink-0 w-40 relative rounded-lg overflow-hidden">
                    <div className="aspect-video bg-gray-100 relative">
                      <Image
                        src={`/placeholder.svg?height=90&width=160&text=Video+${i + 10}`}
                        alt="Recommended video"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 py-0.5 rounded">
                      {Math.floor(Math.random() * 20) + 1}:
                      {Math.floor(Math.random() * 60)
                        .toString()
                        .padStart(2, "0")}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium line-clamp-2 group-hover:text-blue-600">
                      {i % 2 === 0
                        ? "How to Master JavaScript in 2023"
                        : "Top 10 Web Development Frameworks You Should Learn"}
                    </h3>
                    <p className="text-xs text-gray-600 mt-1">Tech Channel {i + 1}</p>
                    <p className="text-xs text-gray-500">
                      {Math.floor(Math.random() * 10) + 1}.{Math.floor(Math.random() * 9)}M views •{" "}
                      {Math.floor(Math.random() * 12) + 1} months ago
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
