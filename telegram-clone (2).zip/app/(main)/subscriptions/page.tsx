import { Button } from "@/components/ui/button"
import { SubscriptionChannel } from "@/components/subscription-channel"

export default function SubscriptionsPage() {
  const channels = [
    {
      id: "tech-insights",
      name: "Tech Insights",
      subscribers: "2.4M subscribers",
      verified: true,
    },
    {
      id: "cooking-simplified",
      name: "Cooking Simplified",
      subscribers: "1.8M subscribers",
      verified: true,
    },
    {
      id: "gaming-chronicles",
      name: "Gaming Chronicles",
      subscribers: "5.2M subscribers",
      verified: true,
    },
    {
      id: "science-explained",
      name: "Science Explained",
      subscribers: "3.7M subscribers",
      verified: true,
    },
    {
      id: "fitness-pro",
      name: "Fitness Pro",
      subscribers: "4.1M subscribers",
      verified: false,
    },
    {
      id: "travel-diaries",
      name: "Travel Diaries",
      subscribers: "2.9M subscribers",
      verified: true,
    },
  ]

  return (
    <div className="p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Subscriptions</h1>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center mb-8">
          <h2 className="text-xl font-medium mb-3">Don't miss new videos</h2>
          <p className="text-gray-600 mb-6">Sign in to see updates from your favorite MTube channels</p>
          <Button className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors">
            Sign in
          </Button>
        </div>

        <h2 className="text-xl font-bold mb-4">Popular on MTube</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {channels.map((channel) => (
            <SubscriptionChannel key={channel.id} channel={channel} />
          ))}
        </div>
      </div>
    </div>
  )
}
