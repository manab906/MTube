import Image from "next/image"
import Link from "next/link"
import { Flame } from "lucide-react"

export default function TrendingPage() {
  const trendingVideos = [
    {
      id: 1,
      title: "The Most Anticipated Game of 2023 - Full Review",
      channel: "Gaming Chronicles",
      channelId: "gaming-chronicles",
      views: "4.2M views",
      timestamp: "2 days ago",
      duration: "18:42",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Game+Review",
      description:
        "We got early access to the most anticipated game of the year. Here's our full review with gameplay footage.",
    },
    {
      id: 2,
      title: "I Lived in a Tiny House for 30 Days - What I Learned",
      channel: "Life Experiments",
      channelId: "life-experiments",
      views: "2.8M views",
      timestamp: "3 days ago",
      duration: "22:15",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Tiny+House",
      description:
        "I decided to downsize my life and live in a 120 sq ft tiny house for a month. Here's what happened.",
    },
    {
      id: 3,
      title: "Making the World's Largest Pizza - We Broke a Record!",
      channel: "Food Challenges",
      channelId: "food-challenges",
      views: "5.7M views",
      timestamp: "1 week ago",
      duration: "34:28",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Giant+Pizza",
      description: "We attempted to break the world record for the largest pizza ever made. Did we succeed?",
    },
    {
      id: 4,
      title: "The Truth About AI - What's Coming in the Next 5 Years",
      channel: "Tech Insights",
      channelId: "tech-insights",
      views: "3.1M views",
      timestamp: "4 days ago",
      duration: "26:19",
      thumbnail: "/placeholder.svg?height=200&width=360&text=AI+Future",
      description:
        "AI experts reveal what's really happening behind the scenes and what to expect in the next 5 years.",
    },
    {
      id: 5,
      title: "I Trained Like a Professional Athlete for 30 Days",
      channel: "Fitness Challenge",
      channelId: "fitness-challenge",
      views: "6.3M views",
      timestamp: "5 days ago",
      duration: "19:54",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Fitness+Challenge",
      description:
        "I followed the exact training regimen of Olympic athletes for a month. The results were surprising.",
    },
    {
      id: 6,
      title: "We Found a Hidden Underground City - Urban Exploration",
      channel: "Urban Explorers",
      channelId: "urban-explorers",
      views: "8.9M views",
      timestamp: "1 week ago",
      duration: "42:07",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Underground+City",
      description: "We discovered an abandoned underground complex that was once a secret government facility.",
    },
    {
      id: 7,
      title: "I Quit Social Media for 6 Months - How It Changed My Life",
      channel: "Digital Detox",
      channelId: "digital-detox",
      views: "3.5M views",
      timestamp: "2 weeks ago",
      duration: "15:32",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Social+Media+Detox",
      description:
        "After being constantly connected for years, I decided to completely disconnect. Here's what happened.",
    },
    {
      id: 8,
      title: "Building a House with Only $10,000 - Is It Possible?",
      channel: "Budget Builders",
      channelId: "budget-builders",
      views: "7.2M views",
      timestamp: "3 weeks ago",
      duration: "28:45",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Budget+House",
      description:
        "We challenged ourselves to build a complete house with just $10,000. See the entire process from start to finish.",
    },
  ]

  return (
    <div className="p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <Flame className="h-6 w-6 text-red-600" />
          <h1 className="text-2xl font-bold">Trending</h1>
        </div>

        <div className="space-y-6">
          {trendingVideos.map((video, index) => (
            <Link href={`/watch?v=${video.id}`} key={video.id} className="flex flex-col md:flex-row gap-4 group">
              <div className="relative md:w-96 flex-shrink-0">
                <div className="aspect-video bg-gray-100 relative rounded-xl overflow-hidden">
                  <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover" />
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-1 py-0.5 rounded">
                    {video.duration}
                  </div>
                </div>
                <div className="absolute top-2 left-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded-full flex items-center">
                  <span className="font-bold mr-1">#{index + 1}</span> Trending
                </div>
              </div>

              <div className="flex-1">
                <h2 className="text-lg font-bold group-hover:text-blue-600 line-clamp-2">{video.title}</h2>
                <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                  <span>{video.views}</span>
                  <span>•</span>
                  <span>{video.timestamp}</span>
                </div>

                <div className="flex items-center gap-2 mt-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-medium text-sm">
                    {video.channel.charAt(0)}
                  </div>
                  <span className="text-sm text-gray-700">{video.channel}</span>
                </div>

                <p className="text-sm text-gray-600 mt-2 line-clamp-2">{video.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
