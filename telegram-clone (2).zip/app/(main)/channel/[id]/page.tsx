import Image from "next/image"
import { CheckCircle2, Bell, Share2, ThumbsUp, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import VideoGrid from "@/components/video-grid"

interface ChannelPageProps {
  params: {
    id: string
  }
}

export default function ChannelPage({ params }: ChannelPageProps) {
  const { id } = params

  // Mock channel data
  const channel = {
    id,
    name: id
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" "),
    subscribers: "2.4M subscribers",
    videos: "342 videos",
    description:
      "Welcome to our channel! We create content about technology, programming, and digital creativity. Subscribe for weekly tutorials, reviews, and tech news.",
    verified: true,
    banner: "/placeholder.svg?height=280&width=1200&text=Channel+Banner",
  }

  return (
    <div>
      {/* Channel Banner */}
      <div className="relative h-32 md:h-48 lg:h-64 w-full bg-gray-200">
        <Image
          src={channel.banner || "/placeholder.svg"}
          alt={`${channel.name} banner`}
          fill
          className="object-cover"
        />
      </div>

      {/* Channel Info */}
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between py-6 gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-2xl md:text-3xl">
              {channel.name.charAt(0)}
            </div>

            <div>
              <div className="flex items-center gap-1">
                <h1 className="text-xl md:text-2xl font-bold">{channel.name}</h1>
                {channel.verified && <CheckCircle2 className="h-5 w-5 text-gray-500 fill-gray-500" />}
              </div>
              <div className="text-sm text-gray-500">
                <span>{channel.subscribers}</span>
                <span className="mx-1">•</span>
                <span>{channel.videos}</span>
              </div>
              <p className="text-sm text-gray-500 hidden md:block mt-1 max-w-md line-clamp-1">{channel.description}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button className="bg-red-600 hover:bg-red-700 text-white">Subscribe</Button>
            <Button variant="outline" size="icon" className="rounded-full">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="outline" size="icon" className="rounded-full">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Channel Tabs */}
        <Tabs defaultValue="videos" className="mb-8">
          <TabsList className="mb-6">
            <TabsTrigger value="videos">Videos</TabsTrigger>
            <TabsTrigger value="playlists">Playlists</TabsTrigger>
            <TabsTrigger value="community">Community</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
          </TabsList>

          <TabsContent value="videos">
            <VideoGrid />
          </TabsContent>

          <TabsContent value="playlists">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="border border-gray-200 rounded-xl overflow-hidden">
                  <div className="aspect-video bg-gray-100 relative">
                    <Image
                      src={`/placeholder.svg?height=200&width=360&text=Playlist+${i + 1}`}
                      alt={`Playlist ${i + 1}`}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <div className="text-white text-center">
                        <div className="text-2xl font-bold">{(i + 1) * 5}</div>
                        <div className="text-sm">videos</div>
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium">
                      Playlist {i + 1}: {i % 2 === 0 ? "Tutorials" : "Reviews"}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">Updated 2 weeks ago</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="community">
            <div className="space-y-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                      {channel.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{channel.name}</span>
                        {channel.verified && <CheckCircle2 className="h-4 w-4 text-gray-500 fill-gray-500" />}
                      </div>
                      <div className="text-xs text-gray-500">{i + 1} week ago</div>
                    </div>
                  </div>

                  <p className="text-sm mb-4">
                    {i === 0
                      ? "We just hit 2 million subscribers! Thank you all for your support. To celebrate, we're giving away 5 premium courses. Comment below to enter!"
                      : i === 1
                        ? "Our new tutorial series on advanced web development starts next week. What topics would you like us to cover?"
                        : "Check out this behind-the-scenes look at our studio setup. Let us know what you think!"}
                  </p>

                  {i === 2 && (
                    <div className="mb-4 rounded-lg overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=400&width=800&text=Studio+Setup"
                        alt="Studio Setup"
                        width={800}
                        height={400}
                        className="w-full h-auto"
                      />
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-sm">
                    <Button variant="ghost" size="sm">
                      <ThumbsUp className="h-4 w-4 mr-2" />
                      {(i + 1) * 1.2}K
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      {(i + 1) * 342}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="about">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <h2 className="text-lg font-bold mb-4">Description</h2>
                <p className="text-sm text-gray-700 whitespace-pre-line">
                  {channel.description}
                  {"\n\n"}
                  We post new videos every Monday, Wednesday, and Friday at 2 PM EST.
                  {"\n\n"}
                  For business inquiries: contact@{id}.com
                </p>

                <div className="mt-8">
                  <h2 className="text-lg font-bold mb-4">Links</h2>
                  <div className="flex flex-wrap gap-3">
                    <Button variant="outline" size="sm" className="rounded-full">
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.164 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.342-3.369-1.342-.454-1.155-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.202 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 .267.18.578.688.48C19.138 20.16 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
                      </svg>
                      GitHub
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full">
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                      </svg>
                      Twitter
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full">
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 .62.08 1.21.21 1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
                      </svg>
                      Website
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full">
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.072 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.057-1.644.07-4.849.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.667.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                      </svg>
                      Instagram
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-lg font-bold mb-4">Stats</h2>
                <div className="bg-gray-100 rounded-lg p-4">
                  <div className="mb-4">
                    <div className="text-sm text-gray-500">Joined</div>
                    <div className="font-medium">Jan 15, 2018</div>
                  </div>
                  <div className="mb-4">
                    <div className="text-sm text-gray-500">Total views</div>
                    <div className="font-medium">48.7M views</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Location</div>
                    <div className="font-medium">United States</div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
