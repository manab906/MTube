import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function LoginPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <div className="w-full max-w-md p-6 text-center">
        <div className="mx-auto w-20 h-20 bg-red-600 rounded-full flex items-center justify-center mb-6">
          <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 12L10 9V15L14 12Z" fill="currentColor" />
            <path
              d="M3 9C3 7.93913 3.42143 6.92172 4.17157 6.17157C4.92172 5.42143 5.93913 5 7 5H17C18.0609 5 19.0783 5.42143 19.8284 6.17157C20.5786 6.92172 21 7.93913 21 9V15C21 16.0609 20.5786 17.0783 19.8284 17.8284C19.0783 18.5786 18.0609 19 17 19H7C5.93913 19 4.92172 18.5786 4.17157 17.8284C3.42143 17.0783 3 16.0609 3 15V9Z"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Sign in to MTube</h1>

        <div className="space-y-4">
          <Link href="/login/email" className="block w-full">
            <Button className="w-full py-3 px-4 bg-red-600 text-white font-medium rounded-md hover:bg-red-700 transition-colors">
              Sign in with Email
            </Button>
          </Link>

          <Link href="/login/google" className="block w-full">
            <Button variant="outline" className="w-full py-3 px-4 font-medium rounded-md border-gray-300">
              Sign in with Google
            </Button>
          </Link>
        </div>

        <p className="mt-8 text-sm text-gray-600">
          By signing in, you agree to our{" "}
          <Link href="/terms" className="text-red-600 hover:underline">
            Terms of Service
          </Link>{" "}
          and{" "}
          <Link href="/privacy" className="text-red-600 hover:underline">
            Privacy Policy
          </Link>
          .
        </p>
      </div>
    </div>
  )
}
