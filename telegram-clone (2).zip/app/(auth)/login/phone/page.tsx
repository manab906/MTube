"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

export default function PhoneLoginPage() {
  const router = useRouter()
  const [phoneNumber, setPhoneNumber] = useState("")
  const [country, setCountry] = useState("US")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Navigate to verification page
    router.push("/login/verify")
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <div className="w-full max-w-md p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-8 text-center">Sign in to Telegram</h1>

        <p className="text-gray-600 mb-6 text-center">Please confirm your country and enter your phone number.</p>

        <form className="space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-2">
            <label htmlFor="country" className="block text-sm font-medium text-gray-700">
              Country
            </label>
            <select
              id="country"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#2AABEE]"
            >
              <option value="US">United States</option>
              <option value="UK">United Kingdom</option>
              <option value="CA">Canada</option>
              <option value="AU">Australia</option>
              {/* More countries would be added here */}
            </select>
          </div>

          <div className="space-y-2">
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
              Phone Number
            </label>
            <input
              type="tel"
              id="phone"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="+1 123 456 7890"
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#2AABEE]"
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full py-3 px-4 bg-[#2AABEE] text-white font-medium rounded-md hover:bg-[#229ED9] transition-colors"
          >
            Next
          </Button>
        </form>

        <div className="mt-6 text-center">
          <Link href="/login/qr" className="text-[#2AABEE] font-medium text-sm hover:underline">
            Log in by QR Code
          </Link>
        </div>
      </div>
    </div>
  )
}
