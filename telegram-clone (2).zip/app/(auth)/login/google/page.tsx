"use client"

import { useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"

export default function GoogleLoginPage() {
  const router = useRouter()

  useEffect(() => {
    // Simulate Google authentication process
    const timer = setTimeout(() => {
      router.push("/")
    }, 3000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <div className="w-full max-w-md p-6 text-center">
        <div className="mx-auto w-20 h-20 bg-red-600 rounded-full flex items-center justify-center mb-6">
          <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 12L10 9V15L14 12Z" fill="currentColor" />
            <path
              d="M3 9C3 7.93913 3.42143 6.92172 4.17157 6.17157C4.92172 5.42143 5.93913 5 7 5H17C18.0609 5 19.0783 5.42143 19.8284 6.17157C20.5786 6.92172 21 7.93913 21 9V15C21 16.0609 20.5786 17.0783 19.8284 17.8284C19.0783 18.5786 18.0609 19 17 19H7C5.93913 19 4.92172 18.5786 4.17157 17.8284C3.42143 17.0783 3 16.0609 3 15V9Z"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Signing in with Google</h1>

        <div className="flex justify-center mb-6">
          <Spinner className="w-8 h-8 border-t-4 border-red-600" />
        </div>

        <p className="text-gray-600 mb-8">Please wait while we authenticate you with Google...</p>

        <Link href="/login">
          <Button variant="outline" className="px-4 py-2">
            Cancel
          </Button>
        </Link>
      </div>
    </div>
  )
}
