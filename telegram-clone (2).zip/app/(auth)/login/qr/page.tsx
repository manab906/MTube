import Link from "next/link"
import Image from "next/image"

export default function QRLoginPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <div className="w-full max-w-md p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-8 text-center">Log in to Telegram by QR Code</h1>

        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm mb-8">
          <div className="aspect-square w-full relative bg-white">
            <Image
              src="/placeholder.svg?height=300&width=300&text=QR+Code"
              alt="QR Code"
              width={300}
              height={300}
              className="w-full h-auto"
            />
          </div>
        </div>

        <div className="text-center space-y-6">
          <div className="space-y-2">
            <p className="text-gray-700 font-medium">Scan this QR code with the Telegram app to log in</p>
            <p className="text-sm text-gray-500">
              Open Telegram on your phone, go to Settings &gt; Devices &gt; Link Desktop Device
            </p>
          </div>

          <div className="pt-4">
            <Link href="/login/phone" className="text-[#2AABEE] font-medium text-sm hover:underline">
              Log in by phone number instead
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
