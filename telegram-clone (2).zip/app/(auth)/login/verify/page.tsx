"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"

export default function VerifyPage() {
  const router = useRouter()
  const [code, setCode] = useState(["", "", "", "", ""])
  const [isLoading, setIsLoading] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => {
    // Focus the first input when the component mounts
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus()
    }
  }, [])

  const handleChange = (index: number, value: string) => {
    if (value.length <= 1) {
      const newCode = [...code]
      newCode[index] = value
      setCode(newCode)

      // Move to next input if there's a value
      if (value && index < 4 && inputRefs.current[index + 1]) {
        inputRefs.current[index + 1].focus()
      }
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Move to previous input on backspace if current is empty
    if (e.key === "Backspace" && !code[index] && index > 0 && inputRefs.current[index - 1]) {
      inputRefs.current[index - 1].focus()
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const fullCode = code.join("")

    if (fullCode.length === 5) {
      setIsLoading(true)

      // Simulate verification with a delay
      setTimeout(() => {
        setIsLoading(false)
        router.push("/chat")
      }, 1500)
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <div className="w-full max-w-md p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-4 text-center">Enter Verification Code</h1>

        <p className="text-gray-600 mb-8 text-center">
          We've sent a 5-digit code to your phone number. Please enter it below.
        </p>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="flex justify-center gap-2">
            {code.map((digit, index) => (
              <input
                key={index}
                type="text"
                ref={(el) => (inputRefs.current[index] = el)}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-14 text-center text-xl font-medium border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#2AABEE]"
                maxLength={1}
                pattern="[0-9]"
                inputMode="numeric"
                autoComplete="one-time-code"
                required
              />
            ))}
          </div>

          <Button
            type="submit"
            className="w-full py-3 px-4 bg-[#2AABEE] text-white font-medium rounded-md hover:bg-[#229ED9] transition-colors"
            disabled={isLoading || code.some((digit) => !digit)}
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <Spinner className="w-5 h-5 mr-2" />
                Verifying...
              </div>
            ) : (
              "Verify Code"
            )}
          </Button>
        </form>

        <div className="mt-6 text-center space-y-3">
          <p className="text-gray-600 text-sm">
            Didn't receive a code? <button className="text-[#2AABEE] font-medium hover:underline">Resend</button>
          </p>

          <Link href="/login/phone" className="text-[#2AABEE] text-sm font-medium hover:underline block">
            Change phone number
          </Link>
        </div>
      </div>
    </div>
  )
}
