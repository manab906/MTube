"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function CategoryPills() {
  const [selectedCategory, setSelectedCategory] = useState("All")

  const categories = [
    "All",
    "Music",
    "Gaming",
    "News",
    "Live",
    "Comedy",
    "Podcasts",
    "Cooking",
    "Education",
    "Sports",
    "Technology",
    "Fashion",
    "Travel",
    "Animation",
    "Fitness",
  ]

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {categories.map((category) => (
        <Button
          key={category}
          variant="outline"
          size="sm"
          className={cn(
            "rounded-full whitespace-nowrap",
            selectedCategory === category
              ? "bg-black text-white hover:bg-black/90"
              : "bg-gray-100 hover:bg-gray-200 text-black",
          )}
          onClick={() => setSelectedCategory(category)}
        >
          {category}
        </Button>
      ))}
    </div>
  )
}
