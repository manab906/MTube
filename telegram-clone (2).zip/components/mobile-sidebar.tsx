"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Home,
  Play,
  Library,
  History,
  Clock,
  ThumbsUp,
  Flame,
  ShoppingBag,
  Music2,
  Film,
  Radio,
  Gamepad2,
  Newspaper,
  Trophy,
  GraduationCapIcon as Graduation,
  Shirt,
  Podcast,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function MobileSidebar() {
  const pathname = usePathname()

  const mainLinks = [
    { href: "/", label: "Home", icon: Home },
    { href: "/shorts", label: "Shorts", icon: Play },
    { href: "/subscriptions", label: "Subscriptions", icon: Library },
  ]

  const libraryLinks = [
    { href: "/history", label: "History", icon: History },
    { href: "/watch-later", label: "Watch later", icon: Clock },
    { href: "/liked-videos", label: "Liked videos", icon: ThumbsUp },
  ]

  const exploreLinks = [
    { href: "/trending", label: "Trending", icon: Flame },
    { href: "/shopping", label: "Shopping", icon: ShoppingBag },
    { href: "/music", label: "Music", icon: Music2 },
    { href: "/movies", label: "Movies & TV", icon: Film },
    { href: "/live", label: "Live", icon: Radio },
    { href: "/gaming", label: "Gaming", icon: Gamepad2 },
    { href: "/news", label: "News", icon: Newspaper },
    { href: "/sports", label: "Sports", icon: Trophy },
    { href: "/learning", label: "Learning", icon: Graduation },
    { href: "/fashion", label: "Fashion & Beauty", icon: Shirt },
    { href: "/podcasts", label: "Podcasts", icon: Podcast },
  ]

  return (
    <div className="h-full overflow-y-auto py-4">
      <div className="px-4 mb-4">
        <Link href="/" className="flex items-center gap-1">
          <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
            <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14 12L10 9V15L14 12Z" fill="currentColor" />
              <path
                d="M3 9C3 7.93913 3.42143 6.92172 4.17157 6.17157C4.92172 5.42143 5.93913 5 7 5H17C18.0609 5 19.0783 5.42143 19.8284 6.17157C20.5786 6.92172 21 7.93913 21 9V15C21 16.0609 20.5786 17.0783 19.8284 17.8284C19.0783 18.5786 18.0609 19 17 19H7C5.93913 19 4.92172 18.5786 4.17157 17.8284C3.42143 17.0783 3 16.0609 3 15V9Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <span className="font-bold text-xl">MTube</span>
        </Link>
      </div>

      <nav className="p-3 space-y-1">
        {mainLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "flex items-center gap-4 px-3 py-2.5 rounded-lg font-medium",
              pathname === link.href ? "bg-gray-100 text-black" : "hover:bg-gray-100 text-black",
            )}
          >
            <link.icon className="h-6 w-6" />
            {link.label}
          </Link>
        ))}

        <div className="border-t my-3 border-gray-200"></div>

        <div className="px-3 py-1 font-medium">You</div>

        {libraryLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="flex items-center gap-4 px-3 py-2.5 rounded-lg hover:bg-gray-100 text-black"
          >
            <link.icon className="h-6 w-6" />
            {link.label}
          </Link>
        ))}

        <div className="py-3 px-4">
          <p className="text-sm mb-3">Sign in to like videos, comment, and subscribe.</p>
          <Link href="/login">
            <Button variant="outline" className="rounded-full border-red-600 text-red-600 hover:bg-red-50">
              Sign in
            </Button>
          </Link>
        </div>

        <div className="border-t my-3 border-gray-200"></div>

        <div className="px-3 py-1 font-medium">Explore</div>

        {exploreLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="flex items-center gap-4 px-3 py-2.5 rounded-lg hover:bg-gray-100 text-black"
          >
            <link.icon className="h-6 w-6" />
            {link.label}
          </Link>
        ))}
      </nav>
    </div>
  )
}
