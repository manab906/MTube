"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Edit, Menu, Sun, Settings, HelpCircle } from "lucide-react"
import { Avatar } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function ChatSidebar() {
  const [searchQuery, setSearchQuery] = useState("")

  const chats = [
    {
      id: "1",
      name: "John Doe",
      lastMessage: "Hey, how are you doing?",
      time: "12:45 PM",
      unread: 2,
    },
    {
      id: "2",
      name: "Jane Smith",
      lastMessage: "Can we meet tomorrow?",
      time: "10:30 AM",
      unread: 0,
    },
    {
      id: "3",
      name: "Tech Support Group",
      lastMessage: "Sarah: I'll look into this issue",
      time: "Yesterday",
      unread: 5,
    },
    {
      id: "4",
      name: "Marketing Team",
      lastMessage: "Meeting postponed to 3pm",
      time: "Yesterday",
      unread: 0,
    },
    {
      id: "5",
      name: "David Wilson",
      lastMessage: "Thanks for your help!",
      time: "Sunday",
      unread: 0,
    },
  ]

  return (
    <div className="w-80 h-full border-r border-gray-200 flex flex-col">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <button className="text-gray-500">
          <Menu className="h-6 w-6" />
        </button>
        <div className="flex-1 mx-3">
          <div className="relative">
            <Input
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 py-2 text-sm bg-gray-100 border-none rounded-full focus:bg-white focus:ring-2 focus:ring-[#2AABEE]"
            />
            <Search className="h-4 w-4 text-gray-500 absolute left-3 top-1/2 transform -translate-y-1/2" />
          </div>
        </div>
        <button className="text-gray-500">
          <Edit className="h-6 w-6" />
        </button>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {chats.map((chat) => (
          <Link href={`/chat/${chat.id}`} key={chat.id} className="block">
            <div className="flex items-center p-3 hover:bg-gray-100 cursor-pointer">
              <Avatar name={chat.name} className="h-12 w-12 bg-[#2AABEE]" />
              <div className="flex-1 min-w-0 ml-3">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-medium text-gray-900 truncate">{chat.name}</h3>
                  <span className="text-xs text-gray-500">{chat.time}</span>
                </div>
                <div className="flex justify-between items-center mt-1">
                  <p className="text-xs text-gray-500 truncate">{chat.lastMessage}</p>
                  {chat.unread > 0 && (
                    <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-[#2AABEE] text-xs text-white">
                      {chat.unread}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Sidebar Footer */}
      <div className="p-3 border-t border-gray-200">
        <div className="flex items-center justify-between mb-2">
          <Button variant="ghost" size="sm" className="text-gray-500 w-full justify-start">
            <Sun className="h-5 w-5 mr-2" />
            Light Mode
          </Button>
        </div>
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" className="text-gray-500 w-1/2 justify-start">
            <Settings className="h-5 w-5 mr-2" />
            Settings
          </Button>
          <Button variant="ghost" size="sm" className="text-gray-500 w-1/2 justify-start">
            <HelpCircle className="h-5 w-5 mr-2" />
            Help
          </Button>
        </div>
      </div>
    </div>
  )
}
