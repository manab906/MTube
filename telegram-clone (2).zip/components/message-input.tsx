"use client"

import type React from "react"

import { useState } from "react"
import { Paperclip, Mic, Smile, Send } from "lucide-react"
import { Button } from "@/components/ui/button"

export function MessageInput() {
  const [message, setMessage] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (message.trim()) {
      console.log("Sending message:", message)
      setMessage("")
    }
  }

  return (
    <div className="p-3 border-t border-gray-200">
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <Button type="button" variant="ghost" size="icon" className="text-gray-500">
          <Paperclip className="h-5 w-5" />
        </Button>
        <div className="flex-1 relative">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Message"
            className="w-full py-2 px-4 bg-gray-100 rounded-full text-sm focus:outline-none"
          />
        </div>
        <Button type="button" variant="ghost" size="icon" className="text-gray-500">
          <Smile className="h-5 w-5" />
        </Button>
        {message.trim() ? (
          <Button type="submit" variant="ghost" size="icon" className="text-[#2AABEE]">
            <Send className="h-5 w-5" />
          </Button>
        ) : (
          <Button type="button" variant="ghost" size="icon" className="text-gray-500">
            <Mic className="h-5 w-5" />
          </Button>
        )}
      </form>
    </div>
  )
}
