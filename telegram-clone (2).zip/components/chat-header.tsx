import { MoreHorizontal, Phone, Search, Video } from "lucide-react"
import { Avatar } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

export function ChatHeader() {
  return (
    <div className="h-16 border-b border-gray-200 flex items-center justify-between px-4">
      <div className="flex items-center gap-3">
        <Avatar name="User Name" className="bg-gray-300" />
        <div>
          <h2 className="font-medium text-gray-900">User Name</h2>
          <p className="text-xs text-gray-500">last seen recently</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="text-gray-500">
          <Search className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-500">
          <Phone className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-500">
          <Video className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-500">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
