import { Avatar } from "@/components/ui/avatar"

export function MessageList() {
  const messages = [
    { id: 1, sender: "other", text: "Hello! How are you?", time: "12:30" },
    { id: 2, sender: "me", text: "I'm good, thanks! How about you?", time: "12:31" },
    { id: 3, sender: "other", text: "Doing well! Just working on some projects.", time: "12:32" },
    { id: 4, sender: "me", text: "That sounds interesting. What kind of projects?", time: "12:33" },
    { id: 5, sender: "other", text: "Mostly web development stuff. Building a new app!", time: "12:34" },
  ]

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
      {messages.map((message) => (
        <div key={message.id} className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}>
          <div className={`flex gap-2 max-w-[70%] ${message.sender === "me" ? "flex-row-reverse" : ""}`}>
            {message.sender !== "me" && <Avatar name="User" className="bg-gray-300 h-8 w-8" />}
            <div
              className={`rounded-lg p-3 ${
                message.sender === "me" ? "bg-[#2AABEE] text-white" : "bg-white border border-gray-200"
              }`}
            >
              <p className="text-sm">{message.text}</p>
              <span
                className={`text-xs block text-right mt-1 ${
                  message.sender === "me" ? "text-blue-100" : "text-gray-500"
                }`}
              >
                {message.time}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
