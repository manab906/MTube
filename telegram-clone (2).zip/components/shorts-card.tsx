import Image from "next/image"
import Link from "next/link"

interface ShortsProps {
  short: {
    id: number
    title: string
    channel: string
    channelId: string
    views: string
    likes: string
    thumbnail: string
  }
}

export function ShortsCard({ short }: ShortsProps) {
  return (
    <div className="group cursor-pointer">
      <Link href={`/shorts/${short.id}`}>
        <div className="relative rounded-xl overflow-hidden mb-2 aspect-[9/16]">
          <div className="w-full h-full bg-gray-100 relative">
            <Image src={short.thumbnail || "/placeholder.svg"} alt={short.title} fill className="object-cover" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
        <h3 className="font-medium text-sm line-clamp-2 group-hover:text-blue-600">{short.title}</h3>
        <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
          <span>{short.views} views</span>
        </div>
      </Link>
    </div>
  )
}
