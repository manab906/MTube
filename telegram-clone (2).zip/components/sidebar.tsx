"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Home,
  Play,
  Library,
  History,
  Clock,
  ThumbsUp,
  Flame,
  ShoppingBag,
  Music2,
  Film,
  Radio,
  Gamepad2,
  Newspaper,
  Trophy,
  GraduationCapIcon as Graduation,
  Shirt,
  Podcast,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function Sidebar() {
  const pathname = usePathname()

  const mainLinks = [
    { href: "/", label: "Home", icon: Home },
    { href: "/shorts", label: "Shorts", icon: Play },
    { href: "/subscriptions", label: "Subscriptions", icon: Library },
  ]

  const libraryLinks = [
    { href: "/history", label: "History", icon: History },
    { href: "/watch-later", label: "Watch later", icon: Clock },
    { href: "/liked-videos", label: "Liked videos", icon: ThumbsUp },
  ]

  const exploreLinks = [
    { href: "/trending", label: "Trending", icon: Flame },
    { href: "/shopping", label: "Shopping", icon: ShoppingBag },
    { href: "/music", label: "Music", icon: Music2 },
    { href: "/movies", label: "Movies & TV", icon: Film },
    { href: "/live", label: "Live", icon: Radio },
    { href: "/gaming", label: "Gaming", icon: Gamepad2 },
    { href: "/news", label: "News", icon: Newspaper },
    { href: "/sports", label: "Sports", icon: Trophy },
    { href: "/learning", label: "Learning", icon: Graduation },
    { href: "/fashion", label: "Fashion & Beauty", icon: Shirt },
    { href: "/podcasts", label: "Podcasts", icon: Podcast },
  ]

  return (
    <aside className="w-64 h-full overflow-y-auto fixed left-0 top-14 pb-20 border-r border-gray-200 hidden md:block">
      <nav className="p-3 space-y-1">
        {mainLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "flex items-center gap-4 px-3 py-2.5 rounded-lg font-medium",
              pathname === link.href ? "bg-gray-100 text-black" : "hover:bg-gray-100 text-black",
            )}
          >
            <link.icon className="h-6 w-6" />
            {link.label}
          </Link>
        ))}

        <div className="border-t my-3 border-gray-200"></div>

        <div className="px-3 py-1 font-medium">You</div>

        {libraryLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="flex items-center gap-4 px-3 py-2.5 rounded-lg hover:bg-gray-100 text-black"
          >
            <link.icon className="h-6 w-6" />
            {link.label}
          </Link>
        ))}

        <div className="py-3 px-4">
          <p className="text-sm mb-3">Sign in to like videos, comment, and subscribe.</p>
          <Link href="/login">
            <Button variant="outline" className="rounded-full border-red-600 text-red-600 hover:bg-red-50">
              Sign in
            </Button>
          </Link>
        </div>

        <div className="border-t my-3 border-gray-200"></div>

        <div className="px-3 py-1 font-medium">Explore</div>

        {exploreLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="flex items-center gap-4 px-3 py-2.5 rounded-lg hover:bg-gray-100 text-black"
          >
            <link.icon className="h-6 w-6" />
            {link.label}
          </Link>
        ))}
      </nav>
    </aside>
  )
}
