"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Menu, Bell, Video, Mic, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { MobileSidebar } from "./mobile-sidebar"

export function Header() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <header className="h-14 bg-white border-b border-gray-200 fixed top-0 left-0 right-0 z-50 flex items-center px-4">
      <div className="flex items-center gap-4">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72">
            <MobileSidebar />
          </SheetContent>
        </Sheet>

        <Button variant="ghost" size="icon" className="hidden md:flex">
          <Menu className="h-6 w-6" />
        </Button>

        <Link href="/" className="flex items-center gap-1">
          <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
            <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14 12L10 9V15L14 12Z" fill="currentColor" />
              <path
                d="M3 9C3 7.93913 3.42143 6.92172 4.17157 6.17157C4.92172 5.42143 5.93913 5 7 5H17C18.0609 5 19.0783 5.42143 19.8284 6.17157C20.5786 6.92172 21 7.93913 21 9V15C21 16.0609 20.5786 17.0783 19.8284 17.8284C19.0783 18.5786 18.0609 19 17 19H7C5.93913 19 4.92172 18.5786 4.17157 17.8284C3.42143 17.0783 3 16.0609 3 15V9Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <span className="font-bold text-xl">MTube</span>
        </Link>
      </div>

      <div className="flex-1 max-w-2xl mx-auto px-4">
        <div className="relative flex items-center">
          <div className="flex-1 flex">
            <input
              type="text"
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 rounded-l-full border border-gray-300 focus:outline-none focus:border-blue-500"
            />
            <button className="bg-gray-100 border border-l-0 border-gray-300 rounded-r-full px-5 py-2 hover:bg-gray-200">
              <Search className="h-5 w-5 text-gray-600" />
            </button>
          </div>
          <button className="ml-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200">
            <Mic className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>

      <div className="flex items-center gap-3 ml-4">
        <Button variant="ghost" size="icon" className="hidden md:flex">
          <Video className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" className="hidden md:flex">
          <Bell className="h-6 w-6" />
        </Button>
        <Link href="/login">
          <Button variant="outline" className="rounded-full">
            <User className="h-5 w-5 mr-2" />
            Sign in
          </Button>
        </Link>
      </div>
    </header>
  )
}
