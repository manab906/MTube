import Image from "next/image"
import Link from "next/link"
import { MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"

interface VideoProps {
  video: {
    id: number
    title: string
    channel: string
    channelId: string
    views: string
    timestamp: string
    duration: string
    thumbnail: string
  }
}

export function VideoCard({ video }: VideoProps) {
  return (
    <div className="group">
      <Link href={`/watch?v=${video.id}`} className="block">
        <div className="relative rounded-xl overflow-hidden mb-2">
          <div className="aspect-video bg-gray-100 relative">
            <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover" />
          </div>
          <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 py-0.5 rounded">
            {video.duration}
          </div>
        </div>
      </Link>

      <div className="flex gap-3">
        <Link href={`/channel/${video.channelId}`} className="flex-shrink-0 mt-1">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-medium text-sm">
            {video.channel.charAt(0)}
          </div>
        </Link>

        <div className="flex-1 min-w-0">
          <Link href={`/watch?v=${video.id}`} className="block">
            <h3 className="font-medium text-sm line-clamp-2 group-hover:text-blue-600">{video.title}</h3>
          </Link>

          <Link href={`/channel/${video.channelId}`} className="text-sm text-gray-600 hover:text-gray-900 block">
            {video.channel}
          </Link>

          <div className="text-xs text-gray-500">
            {video.views} • {video.timestamp}
          </div>
        </div>

        <div className="flex-shrink-0 self-start mt-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full opacity-0 group-hover:opacity-100">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
