import Link from "next/link"
import { CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SubscriptionChannelProps {
  channel: {
    id: string
    name: string
    subscribers: string
    verified: boolean
  }
}

export function SubscriptionChannel({ channel }: SubscriptionChannelProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-2xl">
          {channel.name.charAt(0)}
        </div>
        <div>
          <div className="flex items-center gap-1">
            <Link href={`/channel/${channel.id}`} className="font-medium text-lg hover:text-blue-600">
              {channel.name}
            </Link>
            {channel.verified && <CheckCircle2 className="h-4 w-4 text-gray-500 fill-gray-500" />}
          </div>
          <div className="text-sm text-gray-500">{channel.subscribers}</div>
        </div>
      </div>
      <Button className="w-full bg-red-600 hover:bg-red-700 text-white">Subscribe</Button>
    </div>
  )
}
