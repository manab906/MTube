import { VideoCard } from "@/components/video-card"

export default function VideoGrid() {
  const videos = [
    {
      id: 1,
      title: "How to Build a Modern Website in 2023",
      channel: "Tech Insights",
      channelId: "tech-insights",
      views: "1.2M views",
      timestamp: "3 weeks ago",
      duration: "18:24",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Web+Development",
    },
    {
      id: 2,
      title: "The Ultimate Guide to Machine Learning",
      channel: "AI Academy",
      channelId: "ai-academy",
      views: "856K views",
      timestamp: "2 months ago",
      duration: "42:18",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Machine+Learning",
    },
    {
      id: 3,
      title: "10 Productivity Hacks You Need to Know",
      channel: "Life Optimized",
      channelId: "life-optimized",
      views: "3.4M views",
      timestamp: "1 year ago",
      duration: "12:45",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Productivity+Tips",
    },
    {
      id: 4,
      title: "Easy 30-Minute Recipes for Beginners",
      channel: "Cooking Simplified",
      channelId: "cooking-simplified",
      views: "1.8M views",
      timestamp: "5 months ago",
      duration: "31:07",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Cooking+Recipes",
    },
    {
      id: 5,
      title: "The History of Video Games: Complete Documentary",
      channel: "Gaming Chronicles",
      channelId: "gaming-chronicles",
      views: "4.2M views",
      timestamp: "8 months ago",
      duration: "1:24:36",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Gaming+History",
    },
    {
      id: 6,
      title: "Learn Guitar in 30 Days - Day 1",
      channel: "Music Mastery",
      channelId: "music-mastery",
      views: "2.7M views",
      timestamp: "2 years ago",
      duration: "22:15",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Guitar+Lessons",
    },
    {
      id: 7,
      title: "Understanding Quantum Physics for Beginners",
      channel: "Science Explained",
      channelId: "science-explained",
      views: "1.5M views",
      timestamp: "4 months ago",
      duration: "35:42",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Quantum+Physics",
    },
    {
      id: 8,
      title: "The Art of Cinematography",
      channel: "Film School",
      channelId: "film-school",
      views: "987K views",
      timestamp: "7 months ago",
      duration: "28:53",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Cinematography",
    },
    {
      id: 9,
      title: "How to Start Investing in Stocks - Complete Guide",
      channel: "Finance Explained",
      channelId: "finance-explained",
      views: "2.3M views",
      timestamp: "3 months ago",
      duration: "45:12",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Stock+Investing",
    },
    {
      id: 10,
      title: "The Most Beautiful Places in the World",
      channel: "Travel Diaries",
      channelId: "travel-diaries",
      views: "5.7M views",
      timestamp: "1 year ago",
      duration: "32:18",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Travel+Destinations",
    },
    {
      id: 11,
      title: "How to Build Muscle Fast - Workout Routine",
      channel: "Fitness Pro",
      channelId: "fitness-pro",
      views: "3.1M views",
      timestamp: "6 months ago",
      duration: "19:45",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Fitness+Workout",
    },
    {
      id: 12,
      title: "The Psychology of Success - Mindset Secrets",
      channel: "Mind Matters",
      channelId: "mind-matters",
      views: "1.9M views",
      timestamp: "4 months ago",
      duration: "27:32",
      thumbnail: "/placeholder.svg?height=200&width=360&text=Psychology+Success",
    },
  ]

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {videos.map((video) => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  )
}
